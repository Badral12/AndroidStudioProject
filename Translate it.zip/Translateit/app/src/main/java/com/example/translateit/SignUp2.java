package com.example.translateit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class SignUp2 extends AppCompatActivity {
    TextView name;
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up2);

        UsersDB db = new UsersDB(this, null, null, 1);
        int type =1;
        Translater trans  = db.findByNameAndPass(type,getIntent().getStringExtra("name"), getIntent().getStringExtra("pass"));
        Intent i = getIntent();
        name = (TextView) findViewById(R.id.name);
        name.setText(i.getStringExtra("name"));
        if (trans != null) {
            Toast.makeText(getApplicationContext(), "Бүртгэлтэй байна", Toast.LENGTH_SHORT).show();
            finish();
        }

    }

    public void cancel(View view) {
        finish();
    }


    public void save(View view) {
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("trans");

        UsersDB db = new UsersDB(this, null, null, 1);
        Translater trans = new Translater();
        int turul = getIntent().getIntExtra("turul", 1);
        String name = getIntent().getStringExtra("name");
        EditText pass = findViewById(R.id.etPassSec);

        if(!getIntent().getStringExtra("pass").equals(pass.getText().toString())){
            Toast.makeText(getApplicationContext(),"Нууц үг буруу байна!! Дахин давт", Toast.LENGTH_SHORT).show();
            pass.setText("");
            return;
        }
        EditText gmail = findViewById(R.id.Gmail);
        EditText age = findViewById(R.id.age);
        EditText phone = findViewById(R.id.phone);
        EditText gender = findViewById(R.id.sex);
        EditText L1 = findViewById(R.id.L1);
        EditText L2 = findViewById(R.id.L2);
        EditText L3 = findViewById(R.id.L3);
        EditText Pro = findViewById(R.id.pro);

        trans.setType(turul);
        trans.setName(getIntent().getStringExtra("name"));
        trans.setGmail(gmail.getText().toString());
        trans.setPassword(getIntent().getStringExtra("pass"));
        trans.setAge(Integer.parseInt(age.getText().toString()));
        trans.setPhone(Integer.parseInt(phone.getText().toString()));
        trans.setL1(L1.getText().toString());
        trans.setL2(L2.getText().toString());
        trans.setL3(L3.getText().toString());
        trans.setPro(Pro.getText().toString());
//        System.out.println(Pro.getText().toString());

        if(gender.getText().toString().toLowerCase().contains("er")){
            trans.setGender(0);
        } else if(gender.getText().toString().toLowerCase().contains("em")){
            trans.setGender(1);
        } else {
            trans.setGender(2);
        }

        db.addHandler2(trans);
        reference.child(trans.getName()).setValue(trans);
        Toast.makeText(getApplicationContext(),"Амжилттай бүртгэгдлээ", Toast.LENGTH_SHORT).show();
        finish();

    }
}
