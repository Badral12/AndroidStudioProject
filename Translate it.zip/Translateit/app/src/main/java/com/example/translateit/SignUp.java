package com.example.translateit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.session.MediaSessionManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;


public class SignUp extends AppCompatActivity {

    TextView name;
    FirebaseAuth auth;
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    FirebaseStorage storage;
    Button save;
    ImageButton image;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sign_up);

        UsersDB db = new UsersDB(this, null, null, 1);
        int type = 1;
        Users users = db.findNamePass(type, getIntent().getStringExtra("name"), getIntent().getStringExtra("pass"));
        if (users != null) {
            Toast.makeText(getApplicationContext(), "Бүртгэлтэй байна", Toast.LENGTH_SHORT).show();
            finish();
        }

        Intent i = getIntent();
        name = (TextView) findViewById(R.id.name);
        name.setText(i.getStringExtra("name"));
//
        auth = FirebaseAuth.getInstance();
        storage = FirebaseStorage.getInstance();
        rootNode = FirebaseDatabase.getInstance();
//        image.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent();
//                intent.setAction(Intent.ACTION_GET_CONTENT);
//                intent.setType("image/*");
//                startActivityForResult(intent , 45);
//            }
//        });

    }


        public void save (View view){
            rootNode = FirebaseDatabase.getInstance();
            reference = rootNode.getReference("users");

            UsersDB db = new UsersDB(this, null, null, 1);
            Users users = new Users();
            int turul = getIntent().getIntExtra("turul", 1);
            EditText pass = findViewById(R.id.etPassSec);

            if (!getIntent().getStringExtra("pass").equals(pass.getText().toString())) {
                Toast.makeText(getApplicationContext(), "Нууц үг буруу байна!! Дахин давт", Toast.LENGTH_SHORT).show();
                pass.setText("");
                return;
            }
            EditText gmail = findViewById(R.id.gmail);
            EditText age = findViewById(R.id.age);
            EditText phone = findViewById(R.id.phone);
            EditText gender = findViewById(R.id.gender);


            users.setType(turul);
            users.setName(getIntent().getStringExtra("name"));
            users.setGmail(gmail.getText().toString());
            users.setPassword(getIntent().getStringExtra("pass"));
            users.setAge(Integer.parseInt(age.getText().toString()));
            users.setPhone(Integer.parseInt(phone.getText().toString()));

//        System.out.println(Pro.getText().toString());

            if (gender.getText().toString().toLowerCase().contains("er")) {
                users.setGender(0);
            } else if (gender.getText().toString().toLowerCase().contains("em")) {
                users.setGender(1);
            } else {
                users.setGender(2);
            }

            db.addHandler(users);

            reference.child(users.getName()).setValue(users);


            Toast.makeText(getApplicationContext(), "Амжилттай бүртгэгдлээ", Toast.LENGTH_SHORT).show();
            finish();

        }
}


