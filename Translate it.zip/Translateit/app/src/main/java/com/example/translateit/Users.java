package com.example.translateit;

public class Users {

    private int type;
    private int Id;
    private String Gmail;
    private String name;
    private String password;
    private int age;
    private int gender; //0-man; 1-women
    private int phone;

    public Users(){}
    public Users(int Id, int type, String name , String Gmail, String password, int age, int gender, int phone){
        this.type = type;
        this.Id = Id;
        this.Gmail = Gmail;
        this.name = name;
        this.password = password;
        this.age = age;
        this.gender = gender;
        this.phone = phone;

    }
    public int getType() {return type; }
    public void setType(int type) { this.type = type; }
    public int getId(){return Id;}
    public void setId(int Id ){this.Id= Id;}
    public String getGmail() { return Gmail; }
    public void setGmail(String Gmail) { this.Gmail = Gmail; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public int getGender() { return gender; }
    public void setGender(int gender) { this.gender = gender; }
    public int getPhone() { return phone; }
    public void setPhone(int phone) { this.phone = phone; }


}
