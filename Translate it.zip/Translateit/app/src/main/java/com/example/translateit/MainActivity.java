package com.example.translateit;

import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    EditText name , pass;
    Spinner spinner;
    Button login,Signup;
    Users users;
    FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = (Spinner) findViewById(R.id.spinner);
        login = (Button) findViewById(R.id.Login);
        Signup = (Button) findViewById(R.id.SignUp);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.txt_type, R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        name = (EditText)findViewById(R.id.etUserName);
        pass = (EditText)findViewById(R.id.etPassword);
        auth = FirebaseAuth.getInstance();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String gmail = name.getText().toString();
//                String passs = pass.getText().toString();
//                if(TextUtils.isEmpty(gmail) || TextUtils.isEmpty(passs) ){
//                    Toast.makeText(MainActivity.this, "Нэвтрэх хаяг болон Нууц үг хоосон байж болохгүй. ", Toast.LENGTH_SHORT).show();
//                }else {
//
//                    auth.signInWithEmailAndPassword(gmail, passs).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                        @Override
//                        public void onComplete(@NonNull Task<AuthResult> task) {
//                            if(task.isSuccessful()){
//
//                                Intent i = new Intent (MainActivity.this, UserInfo.class);
//                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//                                startActivity(i);
//                                finish();
//                            }
//                            else Toast.makeText(MainActivity.this, "Нэвтэрч чадсангүй", Toast.LENGTH_SHORT).show();
//                        }
//                    });
//                }
                loginCheck();
            }
        });

        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });

    }

    private void loginCheck() {
          EditText name = findViewById(R.id.etUserName);
          EditText pass = findViewById(R.id.etPassword);
          UsersDB db = new UsersDB(this, null, null, 1);
          int item = spinner.getSelectedItemPosition();

        Log.e("SPinner", "spinner yu ugch bn " + item);

        if (item == 0) {
           Users users = db.findNamePass(item, name.getText().toString(), pass.getText().toString());
            if (users != null) {
                Intent intent = new Intent(this, UserInfo.class);
                intent.putExtra("turul", users.getType());
                intent.putExtra("name", users.getName());
                intent.putExtra("pass", users.getPassword());
                intent.putExtra("age", users.getAge());
                if (users.getGender() == 0) {
                    intent.putExtra("gender", "Эрэгтэй");
                } else if (users.getGender() == 1) {
                    intent.putExtra("gender", "Эмэгтэй");
                } else {
                    intent.putExtra("gender", "Тодорхойгүй");
                }
                intent.putExtra("phone", users.getPhone());

                startActivity(intent);
                Log.e("userinfo getname ? ", "loginCheck: "+ users.getPassword() );
                pass.setText("");
            }
            else {
                Toast.makeText(this,  " Хэрэглэгч дотор бүртгэл олдоснгүй", Toast.LENGTH_SHORT).show();
                pass.setText("");
            }
        }

        else if (item == 1 ) {
            Translater trans = db.findByNameAndPass(item, name.getText().toString(), pass.getText().toString());
            Log.e("SPinner", "item 1 bh estoi  " + item);
//            System.out.println(trans.toString());
            if (trans != null) {

                Intent intent = new Intent(MainActivity.this, TransInfo.class);
                intent.putExtra("Id", trans.getId());
                intent.putExtra("L1", trans.getL1());
                intent.putExtra("L2", trans.getL2());
                intent.putExtra("pro", trans.getPro());
                intent.putExtra("name", trans.getName());
                intent.putExtra("pass", trans.getPassword());
                intent.putExtra("age", trans.getAge());
                if (trans.getGender() == 0) {
                    intent.putExtra("gender", "Эрэгтэй");
                } else if (trans.getGender() == 1) {
                    intent.putExtra("gender", "Эмэгтэй");
                } else {
                    intent.putExtra("gender", "Тодорхойгүй");
                }
                intent.putExtra("phone", trans.getPhone());

                startActivityForResult(intent, 1);
                System.out.println(intent);
                pass.setText("");
            } else {
                Toast.makeText(this, " Орчуулагч дотор бүртгэл олдоснгүй", Toast.LENGTH_SHORT).show();
                pass.setText("");
            }
        }
    }
    private void register() {

        int item = spinner.getSelectedItemPosition();

        if(item == 0 ) {
            EditText name = findViewById(R.id.etUserName);
            EditText pass = findViewById(R.id.etPassword);

            Intent intent = new Intent(this, SignUp.class);
            intent.putExtra("type", item);
            System.out.println(item);
            intent.putExtra("name", name.getText().toString());
            intent.putExtra("pass", pass.getText().toString());
            startActivity(intent);

            pass.setText("");
        }

        if(item == 1 ) {
            EditText name = findViewById(R.id.etUserName);
            EditText pass = findViewById(R.id.etPassword);
            System.out.println(item);
            Log.e("bi hna bn", "register: "+ item );
            Intent intent = new Intent(this, SignUp2.class);
            intent.putExtra("turul", item);
            intent.putExtra("name", name.getText().toString());
            intent.putExtra("pass", pass.getText().toString());
            startActivity(intent);

            pass.setText("");
        }
    }

}


