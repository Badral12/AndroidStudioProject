package com.example.translateit;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class UsersDB extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "hereglegch";
    public static final String TABLE_NAME = "UsersTable";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_ID = "Id";
    public static final String COLUMN_NAME = "Name";
    public static final String COLUMN_GMAIL = "Gmail";
    public static final String COLUMN_PASS = "Password";
    public static final String COLUMN_AGE = "Age";
    public static final String COLUMN_GENDER = "Gender";
    public static final String COLUMN_PHONE = "Phone";


    public static final String _TABLE_NAME = "TransTable";
    public static final String _COLUMN_TYPE = "type";
    public static final String _COLUMN_ID="Id";
    public static final String _COLUMN_NAME = "Name";
    public static final String _COLUMN_GMAIL = "Gmail";
    public static final String _COLUMN_PASS = "Password";
    public static final String _COLUMN_AGE = "Age";
    public static final String _COLUMN_GENDER = "Gender";
    public static final String _COLUMN_PHONE = "Phone";
    public static final String _COLUMN_LANGUAGE1 = "l1";
    public static final String _COLUMN_LANGUAGE2 = "l2";
    public static final String _COLUMN_LANGUAGE3 = "l3";
    public static final String _COLUMN_PROFESSION = "pro";



    public UsersDB( Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super( context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER  PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_TYPE + " INTEGER,"
                + COLUMN_NAME + " TEXT,"
                + COLUMN_GMAIL + " TEXT,"
                + COLUMN_PASS + " TEXT,"
                + COLUMN_AGE + " INTEGER,"
                + COLUMN_GENDER + " INTEGER,"
                + COLUMN_PHONE + " INTEGER )";
        String CREATE_TABLE_2 = "CREATE TABLE " + _TABLE_NAME + "("
                + _COLUMN_ID + " INTEGER  PRIMARY KEY AUTOINCREMENT,"
                + _COLUMN_TYPE + " INTEGER,"
                + _COLUMN_NAME + " TEXT,"
                + _COLUMN_GMAIL + " TEXT,"
                + _COLUMN_PASS + " TEXT,"
                + _COLUMN_AGE + " INTEGER,"
                + _COLUMN_GENDER + " INTEGER,"
                + _COLUMN_PHONE + " INTEGER,"
                + _COLUMN_LANGUAGE1 + " TEXT,"
                + _COLUMN_LANGUAGE2 + " TEXT,"
                + _COLUMN_LANGUAGE3 + " TEXT,"
                + _COLUMN_PROFESSION + " TEXT )";
        db.execSQL(CREATE_TABLE);
        db.execSQL(CREATE_TABLE_2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + _TABLE_NAME);
        onCreate(db);
    }


    public void addHandler(Users users) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_TYPE, users.getType());
        values.put(COLUMN_NAME, users.getName());
        values.put(COLUMN_GMAIL, users.getGmail());
        values.put(COLUMN_PASS, users.getPassword());
        values.put(COLUMN_AGE, users.getAge());
        values.put(COLUMN_GENDER, users.getGender());
        values.put(COLUMN_PHONE, users.getPhone());
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_NAME, null, values);
        db.close();
    }
    public void addHandler2(Translater trans) {
        ContentValues values = new ContentValues();
        values.put(_COLUMN_TYPE, trans.getType());
        values.put(_COLUMN_NAME, trans.getName());
        values.put(_COLUMN_GMAIL, trans.getGmail());
        values.put(_COLUMN_PASS, trans.getPassword());
        values.put(_COLUMN_AGE, trans.getAge());
        values.put(_COLUMN_GENDER, trans.getGender());
        values.put(_COLUMN_PHONE, trans.getPhone());
        values.put(_COLUMN_LANGUAGE1, trans.getL1());
        values.put(_COLUMN_LANGUAGE2, trans.getL2());
        values.put(_COLUMN_LANGUAGE3, trans.getL3());
        values.put(_COLUMN_PROFESSION, trans.getPro());
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(_TABLE_NAME, null, values);
        System.out.println(values);
        db.close();

    }

//    public boolean deleteHandler(int id) {
//        boolean result = false;
//        String query = "Select* FROM " + TABLE_NAME + "WHERE" + COLUMN_ID + "= '" + id + "'";
//        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor cursor = db.rawQuery(query, null);
//        Customer customer = new Customer();
//        if (cursor.moveToFirst()) {
//            customer.setName(cursor.getString(0));
//            db.delete(TABLE_NAME, COLUMN_ID + "=?",
//                    new String[]{String.valueOf(customer.getId())});
//            cursor.close();
//            result = true;
//        }
//        db.close();
//        return result;
//    }

//    public boolean updateNews(Users users) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues args = new ContentValues();
//        args.put(COLUMN_AGE, users.getAge());
//        args.put(COLUMN_GENDER, users.getGender());
//        args.put(COLUMN_PHONE, users.getPhone());
//        int i = db.update(TABLE_NAME, args, COLUMN_NAME + "= '" + users.getName() + "' AND "
//                + COLUMN_PASS + "= '" + users.getPassword() + "'", null);
//        return i == 0;
//    }
//
//    public boolean updatePassword(String name, String oldPass, String newPass) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues args = new ContentValues();
//        args.put(COLUMN_PASS, newPass);
//        int i = db.update(TABLE_NAME, args, COLUMN_NAME + "= '" + name + "' AND "
//                + COLUMN_PASS + "= '" + oldPass + "'", null);
//        return i == 0;
//    }

    public Users findNamePass(int item, String name, String pass) {
            if (name == null || name.isEmpty() || pass == null || pass.isEmpty()) return null;
            String query = "Select * FROM " + TABLE_NAME + " WHERE " + COLUMN_NAME + " = " + "'" + name + "' "
                    + "AND " + COLUMN_PASS + " = " + "'" + pass + "'";

            SQLiteDatabase db = this.getWritableDatabase();
            Cursor cursor = db.rawQuery(query, null);

            Users users = new Users();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                users.setId(Integer.parseInt(cursor.getString(0)));
                users.setType(Integer.parseInt(cursor.getString(1)));
                users.setName(cursor.getString(2));
                users.setGmail(cursor.getString(3));
                users.setPassword(cursor.getString(4));
                users.setAge(Integer.parseInt(cursor.getString(5)));
                users.setGender(Integer.parseInt(cursor.getString(6)));
                users.setPhone(Integer.parseInt(cursor.getString(7)));


                cursor.close();
            } else {
                users = null;
            }
            db.close();
            return users;
        }

    public Translater findByNameAndPass(int item, String name, String pass) {
        Log.e("type", "findByNameAndPass: "+ item );
        if(name == null || name.isEmpty() || pass == null || pass.isEmpty()) return null;
        String query = "Select * FROM " + _TABLE_NAME + " WHERE "  + _COLUMN_NAME + " = " + "'" + name + "' "
                + "AND " + _COLUMN_PASS + " = " + "'" + pass + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        Translater trans = new Translater();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            trans.setType(Integer.parseInt(cursor.getString(0)));
            trans.setId(Integer.parseInt(cursor.getString(1)));
            trans.setName(cursor.getString(2));
            trans.setGmail(cursor.getString(3));
            trans.setPassword(cursor.getString(4));
            trans.setAge(Integer.parseInt(cursor.getString(5)));
            trans.setGender(Integer.parseInt(cursor.getString(6)));
            trans.setPhone(Integer.parseInt(cursor.getString(7)));
            trans.setL1(cursor.getString(8));
            trans.setL2(cursor.getString(9));
            trans.setL3(cursor.getString(10));
            trans.setPro(cursor.getString(11));

            cursor.close();
        } else {
            trans = null;
        }
        db.close();
        return trans;
    }
//    public Translater getTrans(int id) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        String[] query = new String[] {_COLUMN_ID,_COLUMN_NAME,_COLUMN_AGE,_COLUMN_GENDER,_COLUMN_LANGUAGE1,_COLUMN_LANGUAGE2, _COLUMN_PROFESSION};
//        Cursor cursor=  db.query(TABLE_NAME,query,_COLUMN_ID+"=?",new String[]{String.valueOf(id)},null,null,null,null);
//        if(cursor != null)
//            cursor.moveToFirst();
//
//        return new Translater(
//                Long.parseLong(cursor.getString(1)),
//                cursor.getString(2),
//                Integer.parseInt(cursor.getString(4)),
//                Integer.parseInt(cursor.getString(5)),
//                cursor.getString(7),
//                cursor.getString(8),
//                cursor.getString(10));
//
//    }
    public Translater getTrans(long id) {
        Log.e("id orj irj bn u ? ", "getTrans: "+ id );
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + _TABLE_NAME + " WHERE " + _COLUMN_ID + " = " + "'" + id + "'";
        Cursor cursor = db.rawQuery(query, null);
        Translater trans = new Translater();
        if (cursor.moveToFirst()) {
            do {
                trans.setId(Long.parseLong(cursor.getString(1)));
                trans.setName(cursor.getString(2));
                trans.setAge(Integer.parseInt(cursor.getString(5)));
                trans.setGender(Integer.parseInt(cursor.getString(6)));
                trans.setL1(cursor.getString(8));
                trans.setL2(cursor.getString(9));
                trans.setPro(cursor.getString(11));
            } while (cursor.moveToNext());
        }
        Log.e("trans butsaah utga", "getTrans: " + trans );
        return trans;
    }
    public List<Translater> getAllTrans() {
        List<Translater> allTrans = new ArrayList<>();
        String query = "SELECT * FROM " + _TABLE_NAME+" ORDER BY "+_COLUMN_ID+" DESC";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            do{
                Translater trans = new Translater();
                trans.setId((int) Long.parseLong(cursor.getString(1)));
                trans.setName(cursor.getString(2));
                trans.setL1(cursor.getString(8));
                trans.setL2(cursor.getString(9));
                allTrans.add(trans);
            }while (cursor.moveToNext());
        }
        return allTrans;
    }

    public List<Translater> search(String text, String text2) {
        List<Translater> allTrans = new ArrayList<>();
        Log.e("type", "findByNameAndPass: "+ text );
        String query = "Select * FROM " + _TABLE_NAME + " WHERE "  + _COLUMN_LANGUAGE1 + " = " + "'" + text + "' "
                + "AND " + _COLUMN_LANGUAGE2 + " = " + "'" + text2 + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst()){
            do{
                Translater trans = new Translater();
                trans.setId((int) Long.parseLong(cursor.getString(1)));
                trans.setName(cursor.getString(2));
                trans.setL1(cursor.getString(8));
                trans.setL2(cursor.getString(9));
                allTrans.add(trans);
            }while (cursor.moveToNext());
        }
        return allTrans;
    }

}
