package com.example.translateit;

public class Translater {

    private int type;
    private long Id;
    private String name;
    private String Gmail;
    private String password;
    private int age;
    private int gender; //0-man; 1-women
    private int phone;
    private String L1;
    private String L2;
    private String L3;
    private String pro; // professional

    public Translater(){}

    public Translater(int type, String name, String Gmail, String password, int age, int gender, int phone, String L1,String L2,String L3,String pro){
        this.type = type;
        this.name = name;
        this.Gmail = Gmail;
        this.password = password;
        this.age = age;
        this.gender = gender;
        this.phone = phone;
        this.L1 = L1;
        this.L2 = L2;
        this.L3 = L3;
        this.pro = pro;

    }

    public Translater(long Id, String name, int age, int gender, String l1, String l2, String pro) {
            this.Id = Id;
            this.name = name;
            this.age = age;
            this.gender = gender;
            this.L1 = l1;
            this.L2 = l2;
            this.pro = pro;
        }

    public String getGmail(){return Gmail;}
    public void setGmail(String Gmail){this.Gmail= Gmail;}
    public String getL1(){return L1;}
    public void setL1(String L1){this.L1= L1;}
    public String getL2(){return L2;}
    public void setL2(String L2){this.L2= L2;}
    public String getL3(){return L3;}
    public void setL3(String L3){this.L3= L3;}
    public String getPro(){return pro;}
    public void setPro(String pro ){this.pro= pro;}
    public long getId(){return Id;}
    public void setId(long Id ){this.Id= Id;}
    public int getType() {return type; }
    public void setType(int type) { this.type = type; }

    @Override
    public String toString() {
        return "Translater{" +
                "type=" + type +
                ", Id=" + Id +
                ", name='" + name + '\'' +
                ", password='" + password + '\'' +
                ", age=" + age +
                ", gender=" + gender +
                ", phone=" + phone +
                ", L1='" + L1 + '\'' +
                ", L2='" + L2 + '\'' +
                ", L3='" + L3 + '\'' +
                ", pro='" + pro + '\'' +
                '}';
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public int getGender() { return gender; }
    public void setGender(int gender) { this.gender = gender; }
    public int getPhone() { return phone; }
    public void setPhone(int phone) { this.phone = phone; }


}
