package com.example.translateit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.content.Intent;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import com.example.translateit.adapters.Adapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class UserInfo extends AppCompatActivity {
    TextView nontext, Tname;
    RecyclerView recycler;
    List<Translater> trans;
    Adapter adapter;
    UsersDB db;
    Spinner spin , spin2;
    Button haih,cancel, all;
    FirebaseUser firebaseUser;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        spin = (Spinner) findViewById(R.id.spinner);
        spin2 = (Spinner) findViewById(R.id.spinner2);
        haih = (Button)findViewById(R.id.Search) ;
        cancel = (Button)findViewById(R.id.Cancel);
//        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
//        reference = FirebaseDatabase.getInstance().getReference("users").child(firebaseUser.getDisplayName());
//        reference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                Users users = dataSnapshot.getValue(Users.class);
//                Toast.makeText(UserInfo.this, "Хэрэглэгч : "+users.getName(), Toast.LENGTH_SHORT).show();
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });
        Intent i = getIntent();
        Tname = (TextView) findViewById(R.id.name);
        Tname.setText(getIntent().getStringExtra("name"));
        ArrayAdapter<CharSequence> l1 = ArrayAdapter.createFromResource(this, R.array.language1, R.layout.support_simple_spinner_dropdown_item);
        spin.setAdapter(l1);
        ArrayAdapter<CharSequence> l2 = ArrayAdapter.createFromResource(this, R.array.language2, R.layout.support_simple_spinner_dropdown_item);
        spin2.setAdapter(l2);
        nontext = findViewById(R.id.noItemText);
        db = new UsersDB(this,null,null,1);
        List<Translater> allTrans = db.getAllTrans();
        recycler = findViewById(R.id.allTrans);

        if(allTrans == null ){
            nontext.setVisibility(View.VISIBLE);
        }else {
            nontext.setVisibility(View.GONE);
            displayList(allTrans);
        }

        haih.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onResume();
            }
        });


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(UserInfo.this, MainActivity.class));

                finish();
                return true;
            case R.id.friends:
                startActivity(new Intent(UserInfo.this, chat.class));

                finish();
                return true;
        }
        return false;
    }


    private void search() {
        UsersDB db = new UsersDB(this, null, null, 1);
        String text = spin.getSelectedItem().toString();
        String text2 = spin2.getSelectedItem().toString();
        List<Translater> allTrans;
        allTrans = db.search(text, text2);
        if(allTrans != null) {
            recycler.setLayoutManager(new LinearLayoutManager(this));
            adapter = new Adapter(this, allTrans);
            recycler.setAdapter(adapter);
        } else Toast.makeText(getApplicationContext(), " Хайлтын үр дүн хоосон", Toast.LENGTH_SHORT).show();
    }


    private void displayList(List<Translater> allTrans) {
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Adapter(this, allTrans);
        recycler.setAdapter(adapter);

    }

    @Override


    protected void onResume() {
        super.onResume();
        List<Translater> allTrans = db.getAllTrans();
        if(allTrans.isEmpty()){
            nontext.setVisibility(View.VISIBLE);
        }else {
            nontext.setVisibility(View.GONE);
            displayList(allTrans);
        }
    }
}