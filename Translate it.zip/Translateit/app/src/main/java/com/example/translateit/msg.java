package com.example.translateit;

public class msg {
    private int Id;
    private String sender;
    private String receiver;
    private String msg;

    public msg(){}

    public msg(int Id, String sender , String receiver, String msg){
        this.Id = Id;
        this.sender = sender;
        this.receiver = receiver;
        this.msg = msg;
    }
    public int getId(){return Id;}
    public void setId(int Id ){this.Id= Id;}
    public String getSender() { return sender; }
    public void setSender(String sender) { this.sender = sender; }
    public String getReceiver() { return receiver; }
    public void setReceiver(String receiver) { this.receiver = receiver; }
    public String getMsg() { return sender; }
    public void setMsg(String sender) { this.sender = sender; }

}