package com.example.translateit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.transition.Transition;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class TransInfo extends AppCompatActivity {
    TextView name, about, l1,l2;
    RecyclerView recycle;
    Translater trans;
    long id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trans_info);
        TextView name = (TextView) findViewById(R.id.name);
        TextView about = (TextView) findViewById(R.id.about);
        TextView l1 = (TextView) findViewById(R.id.l1);
        TextView l2 = (TextView) findViewById(R.id.l2);

        Intent i = getIntent();
        System.out.println(i);
        id = i.getLongExtra("ID",0);
        System.out.println(id);
        UsersDB db = new UsersDB(this, null,null,1);
        trans = db.getTrans(id);
        name.setText(i.getStringExtra("name"));
        System.out.println(name);
        if( trans.getGender() > 0)
        about.setText( trans.getPro()+ " мэргэжилтэй " + trans.getAge() + " настай эрэгтэй орчуулагч ");
        else
        about.setText( trans.getPro()+ " мэргэжилтэй " + trans.getAge() + " настай эмэгтэй орчуулагч ");
        l1.setText(trans.getL1() + " хэлтэй ");
        l2.setText(trans.getL2() + " хэлтэй ");
        FloatingActionButton fab = findViewById(R.id.call);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { ;
                Toast.makeText(getApplicationContext(),"Холбогдлоо",Toast.LENGTH_SHORT).show();
                Intent i = new Intent(TransInfo.this, Messagetrans.class);
                i.putExtra("Tname", trans.getName());
                goToMain();
            }
        });


    }
    private void goToMain() {
        Intent i = new Intent(this, Messagetrans.class);
        i.putExtra("name", trans.getName());
        startActivity(i);
    }
}