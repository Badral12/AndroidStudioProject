package com.example.translateit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.translateit.adapters.Adapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.util.HashMap;
import java.util.List;

public class Messagetrans extends AppCompatActivity {
    TextView name;
    ImageView image;
    RecyclerView view;
    List<msg> msg;
    EditText msgtext;
    ImageButton send;
    FirebaseDatabase database;
    FirebaseUser firebaseUser;
    DatabaseReference reference;
    FirebaseStorage storage;
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messagetrans);

        image = findViewById(R.id.image);
        name = findViewById(R.id.name);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        send = findViewById(R.id.send);
        msgtext = findViewById(R.id.sendmsg);

        i = getIntent();
        String transName = i.getStringExtra("name");
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("trans").child(transName);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Translater trans = dataSnapshot.getValue(Translater.class);
                name.setText(trans.getName());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        final String reciever= getIntent().getStringExtra("Tname");
        String sender = getIntent().getStringExtra("name");
        database = FirebaseDatabase.getInstance();
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Users users = new Users();
                msg msg = new msg();
                Translater trans = new Translater();
                String sender = users.getName();
                String zurwas = msgtext.getText().toString();

                if (zurwas.equals("")) {
                    Toast.makeText(Messagetrans.this, "u have to write something", Toast.LENGTH_SHORT).show();
                    msgtext.setText("");
                } else
                database = FirebaseDatabase.getInstance();
                reference = database.getReference("chats");
                sendMessage(sender, reciever, zurwas);

                msgtext.setText("");
            }
        });
    }

//    private void displayList(List<Translater> allTrans) {
//        recycler.setLayoutManager(new LinearLayoutManager(this));
//        adapter = new Adapter(this, allTrans);
//        recycler.setAdapter(adapter);

//    }
    private void sendMessage(String sender, String receiver , String zurwas){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();

        HashMap<String , Object> hashMap = new HashMap<>();
        hashMap.put("sender", sender);
        hashMap.put("reciever", receiver);
        hashMap.put("msg", zurwas);

        reference.child("chats").push().setValue(hashMap);
    }
}